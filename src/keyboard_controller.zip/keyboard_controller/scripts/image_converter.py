#!/usr/bin/env python
import roslib
import sys
import rospy
import cv2
import numpy as np
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError

## ASSUMES BOTTOM CAMERA IS TOGGLED!

class image_converter:

  def __init__(self):
    self.image_pub = rospy.Publisher("image_converter_output",Image)

    self.bridge = CvBridge()
    self.image_sub = rospy.Subscriber("/ardrone/bottom/image_raw",Image,self.callback)

  def callback(self,data):
    try:
      cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
    except CvBridgeError as e:
      print(e)

    hsv = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)
    lower_blue = np.array([110,80,20])
    upper_blue = np.array([130,255,160])
    mask_b = cv2.inRange(hsv, lower_blue, upper_blue)

    closing_b = cv2.erode(mask_b,np.ones((6,6),np.uint8),iterations = 1)
    dilation_b = cv2.dilate(closing_b,np.ones((20,20),np.uint8),iterations = 1)
 
    lower_red = np.array([165,100,30])
    upper_red = np.array([179,255,150])
    mask_r = cv2.inRange(hsv, lower_red, upper_red)

    closing_r = cv2.erode(mask_r,np.ones((6,6),np.uint8),iterations = 1)
    dilation_r = cv2.dilate(closing_r,np.ones((20,20),np.uint8),iterations = 1)

    mask_br = cv2.bitwise_and(dilation_r,dilation_b)
    mask_br = cv2.dilate(mask_br,np.ones((50,50),np.uint8),iterations = 1)

    res = cv2.bitwise_and(cv_image,cv_image, mask= mask_br)
    cv2.imshow('res',res)
    cv2.imshow('frame',cv_image)
    cv2.waitKey(1)

    '''
    gray = cv2.cvtColor(cv_image,cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray,0,150,apertureSize = 3)

    lines = cv2.HoughLines(edges,1,np.pi/180,200)
	
    
    if lines!=None:
    	for rho,theta in lines[0]:
	    	a = np.cos(theta)
	    	b = np.sin(theta)
	    	x0 = a*rho
	    	y0 = b*rho
	    	x1 = int(x0 + 1000*(-b))
	    	y1 = int(y0 + 1000*(a))
	    	x2 = int(x0 - 1000*(-b))
	    	y2 = int(y0 - 1000*(a))

	    	cv2.line(cv_image,(x1,y1),(x2,y2),(0,0,255),20)
		print("hello")

    cv2.imshow("Image window", cv_image)
    cv2.waitKey(3)
    '''

    try:
      self.image_pub.publish(self.bridge.cv2_to_imgmsg(cv_image, "bgr8"))
    except CvBridgeError as e:
      print(e)

def main(args):
  ic = image_converter()
  rospy.init_node('image_converter', anonymous=True)
  try:
    rospy.spin()
  except KeyboardInterrupt:
    print("Shutting down")
  cv2.destroyAllWindows()

if __name__ == '__main__':
    main(sys.argv)
