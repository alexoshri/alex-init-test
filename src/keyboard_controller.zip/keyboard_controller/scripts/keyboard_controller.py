#!/usr/bin/env python
import sys,select,termios,tty

import rospy,roslib
from std_msgs.msg import String, Empty


quitChar = 'q'
keyCommands = {
		'i':"SET_VELOCITY 0.1 0 0 0 0 0",
		'k':"SET_VELOCITY -0.1 0 0 0 0 0",
		'l':"SET_VELOCITY 0 0 0 0 0 -0.1",
		'j':"SET_VELOCITY 0 0 0 0 0 0.1",
                'h':"SET_VELOCITY 0 0 0.3 0 0 0",
                'b':"SET_VELOCITY 0 0 -0.3 0 0 0",
                'y':"SET_VELOCITY 0 -0.1 0 0 0 0",
                't':"SET_VELOCITY 0 0.1 0 0 0 0",
                'z':"TAKEOFF",
                'x':"LAND",
                'c':"HOVER",
                'v':"RESET"
	       }
directCommands = {
                'e':"DIRECT_EMERGENCY",
                'w':"DIRECT_LAND",
                'r':"DIRECT_TAKEOFF",
                }

class _Getch:
    def __init__(self):
        import tty, sys

    def __call__(self):
        import sys, tty, termios
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(sys.stdin.fileno())
            ch = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        return ch
    

if __name__ == "__main__":
    ### change topic turtle/drone!!!
    pub = rospy.Publisher('/drone_controller/com', String, queue_size = 1)
    pubEmergency = rospy.Publisher('/ardrone/reset', Empty, queue_size = 1)
    pubLand = rospy.Publisher('/ardrone/land', Empty, queue_size = 1)
    pubTakeoff = rospy.Publisher('/ardrone/takeoff', Empty, queue_size = 1)
    
    rospy.init_node('keyboard_controller')
    getch = _Getch()

    while(1):
        key = getch()
        if key in keyCommands:
                command = keyCommands[key]
                
                print("received command from keyboard:")
                print("key: {0}, command: {1}".format(key,command))

		pub.publish(command)
        elif key in directCommands:
            if directCommands[key] == "DIRECT_EMERGENCY":
                print("direct command: DIRECT_EMERGENCY")
                pubEmergency.publish(Empty())
            elif directCommands[key] == "DIRECT_LAND":
                print("direct command: DIRECT_LAND")
                pubLand.publish(Empty())
            elif directCommands[key] == "DIRECT_TAKEOFF":
                print("direct command: DIRECT_TAKEOFF")
                pubTakeoff.publish(Empty())
        elif key == quitChar:
                break




