#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy,roslib
from std_msgs.msg import String, Bool, Empty
from ardrone_autonomy.msg import Navdata
from drone_controller import droneStatus
from ardrone_project.msg import ImageCalc

class follow_controller:
    def __init__(self):
        self.enableControl = False
        self.shift = None
        self.angle = None
        self.time_stamp = None
        self.is_visible = False

        rospy.init_node('follow_controller',anonymous = False)
        self._pubCommand = rospy.Publisher('drone_controller/com', String ,queue_size = 1)
        self._rateCommand = rospy.Rate(8) #5Hz
        self._rateHover = rospy.Rate(5)  # 5Hz

        rospy.Subscriber('image_converter/calc', ImageCalc, self.callbackCalc)
        rospy.Subscriber('image_converter/is_visible', Bool, self.callbackIsVisible)
        rospy.Subscriber('ardrone/navdata', Navdata, self.callbackNavdata)
        rospy.Subscriber('follow_controller/enable_control', Bool, self.callbackEnableControl)        

    def callbackEnableControl(self, msg):
        flag = msg.data
        print("Enable/Disable Control = {}".format(flag) + "\n")
        self.enableControl = flag
	

    def callbackNavdata(self,navdata):        
        self._droneStatus = navdata.state
    
    def callbackCalc(self,data):
        """

        :type data: ImageCalc object
        """
        self.shift = data.shift
        self.angle = data.angle
        self.time_stamp = data.time_stamp
        self.arrow_x = data.arrow_x
        self.arrow_y = data.arrow_y
        self.distance = data.distance

    def callbackIsVisible(self,data):
        self.is_visible = data.data
        if self.enableControl == True and self.is_visible == False: #if control enables and path is not visible
            command = "LAND"
            print("follow_cntroller: " + command + "\n")
            controller._pubCommand.publish(command)


    def cleanup(self):
        print("followController cleanup method")

    def sleep(self):
        self._rateCommand.sleep()


if __name__ == "__main__":
    controller = follow_controller()
    try:
        while not rospy.is_shutdown():
            if (controller.enableControl) and (controller.is_visible): # if control enabled and path is visible
                #horiz_vel = (1/1000) * controller.shift # POSITIVE velocity = move LEFT
                x_vel = -float(controller.arrow_x)*0.001
                y_vel = -float(controller.arrow_y)*0.001
                command = "SET_VELOCITY {} {} 0 0 0 0".format(x_vel, y_vel)
                print("follow_cntroller: " + command + " frame_time_stamp: {} {}".format(controller.time_stamp.secs, controller.time_stamp.nsecs) + "\n")
                controller._pubCommand.publish(command)
                controller.sleep()

                command = "HOVER"
                print("follow_cntroller: " + command + " frame_time_stamp: {} {}".format(controller.time_stamp.secs, controller.time_stamp.nsecs)+ "\n")
                controller._pubCommand.publish(command)
                controller._rateHover.sleep()

                angular_vel = 0.01 * controller.angle
                command = "SET_VELOCITY 0 0 0 0 0 {}".format(angular_vel)
                print("follow_cntroller: " + command + " frame_time_stamp: {} {}".format(controller.time_stamp.secs, controller.time_stamp.nsecs)+ "\n")
                controller._pubCommand.publish(command)
                controller.sleep()
                    
                command = "HOVER"
                print("follow_cntroller: " + command + " frame_time_stamp: {} {}".format(controller.time_stamp.secs, controller.time_stamp.nsecs)+ "\n")
                controller._pubCommand.publish(command)
                controller._rateHover.sleep()

    except rospy.ROSInterruptException:
        print("droneController: ROSInterruptException")
    finally:
        controller.cleanup()

